<?php $__env->startSection('content'); ?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2 justify-content-center">
            <div class="col-12 col-md-8 col-lg-6 text-center">
                <h1>Tambah Transaksi Pembelian</h1>
            </div>
        </div>
    </div><!-- /.container-fluid -->
</section>

<!-- Main content -->
<section class="content">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-8">
                <div class="card">
                    <div class="card-header">
                        <form id="form" action="<?php echo e(route('pembelian.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row justify-content-center align-items-center g-3 mb-3" id="produk-rows">
                                <div class="col-12">
                                    <button type="button" class="btn btn-success" id="add-row">
                                        <span>Tambah Produk</span>
                                    </button>
                                </div>
                                <!-- Baris produk default -->
                                <?php $__currentLoopData = old('produk_id', [null]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $old_produk_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row ms-0 g-2 produk-row">
                                    <div class="col-6 col-lg-7">
                                        <label for="exampleFormControlSelect1" class="form-label">Nama Produk</label>
                                        <select title="nama produk" name="produk_id[]" id="produk" class="form-control select2" aria-label="Default select example" required>
                                            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php echo e($old_produk_id == $item->id ? 'selected' : ''); ?>>
                                                    <?php echo e($item->nama_produk); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-4 col-lg-4">
                                        <label for="exampleFormControlInput1" class="form-label">Jumlah</label>
                                        <input name="jumlah[]" type="number" class="form-control" placeholder="Jumlah produk" value="<?php echo e(old('jumlah.' . $index)); ?>" required oninvalid="this.setCustomValidity('Jumlah harus lebih dari 1')"
                                        oninput="setCustomValidity(''); formatNumber(this)" min="1"/>
                                        <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-2 col-lg-1 d-flex align-items-start" style="margin-top: 2.4rem;">
                                        <button type="button" class="btn btn-danger remove-row">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="row">
                                <div class="col-12 col-lg-6">
                                    <label for="metode_pembayaran" class="form-label">Metode Pembayaran</label>
                                    <select title="metode pembayaran" name="metode_pembayaran" id="metode_pembayaran" class="form-control" aria-label="Default select example" required>
                                        <option value="tunai" <?php echo e(old('metode_pembayaran') == 'tunai' ? 'selected' : ''); ?>>Tunai</option>
                                        <option value="qris" <?php echo e(old('metode_pembayaran') == 'qris' ? 'selected' : ''); ?>>Qris</option>
                                    </select>
                                </div>
                                <div class="col-12 col-lg-6">
                                    <label for="exampleFormControlInput1" class="form-label">Tanggal</label>
                                    <input name="tanggal" type="datetime-local" class="form-control" id="exampleFormControlInput1" required/>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="catatan" class="form-label">Catatan</label>
                                <textarea title="catatan" name="catatan" id="catatan" class="form-control" rows="3"><?php echo e(old('catatan')); ?></textarea>
                                <small class="form-text text-muted">Kosongi jika tidak ada catatan.</small>
                            </div>
                            <div class="d-flex justify-content-end align-items-center">
                                <div class="mr-4">
                                    <a class="btn btn-secondary" href="<?php echo e(route('pembelian')); ?>">Batal</a>
                                </div>
                                <div>
                                    <button type="submit" name="create" class="btn btn-primary">Tambah</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <script>
        function formatNumber(input) {
            let value = input.value.replace(/\D/g, '');
            value = value.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
            input.value = value;
        }
        document.getElementById('add-row').addEventListener('click', function() {
            const container = document.getElementById('produk-rows');
            const index = container.querySelectorAll('.produk-row').length;
            const newRow = document.createElement('div');
            newRow.classList.add('row', 'ms-0', 'g-2', 'produk-row');
            newRow.innerHTML = `
                <div class="col-6 col-lg-7">
                    <label class="form-label">Nama Produk</label>
                    <select title="nama produk" name="produk_id[]" id="produk" class="form-control select2" aria-label="Default select example" required>
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('produk_id.${index}') == $item->id ? 'selected' : ''); ?>>
                                <?php echo e($item->nama_produk); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-4 col-lg-4">
                    <label class="form-label">Jumlah</label>
                    <input name="jumlah[]" type="number" class="form-control" placeholder="Jumlah produk" oninput="formatNumber(this)" min="1" value="<?php echo e(old('jumlah.${index}')); ?>" required />
                </div>

                <div class="col-2 col-lg-1 d-flex align-items-start" style="margin-top: 2.2rem;">
                    <button type="button" class="btn btn-danger remove-row">
                        <i class="fa fa-trash" aria-hidden="true"></i>
                    </button>
                </div>
            `;
            container.appendChild(newRow);
        });

        // Menggunakan event delegation untuk menghapus baris produk
        document.getElementById('produk-rows').addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-row') || event.target.closest('.remove-row')) {
                const row = event.target.closest('.produk-row');
                row.remove();
            }
        });
    </script>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAN\beban\Tugas Akhir\project ta\Sistem_Informasi_Laros_Cell_2-main\Sistem_Informasi_Laros_Cell\resources\views/pembelian/create.blade.php ENDPATH**/ ?>