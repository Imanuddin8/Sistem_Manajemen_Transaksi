<?php $__env->startSection('content'); ?>
<section class="content-header">
  <div class="container-fluid">
    <div class="row">
      <div class="col-12 col-md-8 col-lg-12">
        <h1>Produk</h1>
        <p>Daftar produk pada Toko Laros Cell</p>
      </div>
    </div>
  </div>
</section>

<!-- Main content -->
<section class="content">
<div class="container-fluid">
  <div class="row">
    <div class="col-12 col-md-8 col-lg-12">
      <div class="card">
        <div class="card-body">
            <div class="mb-4">
                <a type="button" class="btn btn-primary btn-md" href="<?php echo e(route('produk.create')); ?>" role="button">
                    <i class="fa fa-plus"></i> Tambah
                </a>
              </div>
            <table id="myTable" class="table table-bordered table-hover">
                <thead class="text-center">
                    <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Harga Beli</th>
                    <th>Harga Jual</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="text-start">
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($row->nama_produk); ?></td>
                            <td><?php echo e($row->kategori); ?></td>
                            <td>Rp <?php echo e(number_format($row->harga_beli, 0, ',', '.')); ?></td>
                            <td>Rp <?php echo e(number_format($row->harga_jual, 0, ',', '.')); ?></td>
                            <td><?php echo e(number_format($row->stok, 0, ',', '.')); ?></td>
                            <td class="d-flex justify-content-center">
                                <a href="<?php echo e(route('produk.edit', ['id' => $row->id])); ?>" type="button" class="btn btn-icon btn-warning mr-2" name="edit">
                                    <i class="text-white fa fa-edit" aria-hidden="true"></i>
                                </a>
                                <form action="<?php echo e(route('produk.destroy', $row->id)); ?>" method="POST" class="delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="button" id="hapus" class="btn btn-icon btn-danger" data-id="<?php echo e($row->id); ?>">
                                        <i class="text-white fa fa-trash" aria-hidden="true"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const deleteButtons = document.querySelectorAll('#hapus');

        deleteButtons.forEach(button => {
            button.addEventListener('click', function () {
                const form = this.closest('.delete-form');
                Swal.fire({
                    title: 'Hapus produk!',
                    text: "Apakah anda yakin ingin menghapus produk?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Iya, Hapus produk!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                })
            });
        });
    });
</script>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\MAN\beban\Tugas Akhir\project ta\Sistem_Informasi_Laros_Cell_2-main\Sistem_Informasi_Laros_Cell\resources\views/produk/produk.blade.php ENDPATH**/ ?>