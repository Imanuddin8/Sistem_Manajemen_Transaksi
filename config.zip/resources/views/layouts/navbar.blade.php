<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto mr-2">
       <span class="fw-bold fs-3" style="color: #00D6C3;">Laros <span style="color: #0C9FCD;">Cell</span></span>
    </ul>
</nav>
<!-- /.navbar -->
